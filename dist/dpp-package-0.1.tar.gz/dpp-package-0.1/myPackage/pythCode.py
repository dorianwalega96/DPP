import random import randint

def randomize(min, max):
	rand = randint(min, max)
	print(rand)
	return rand
